

**EFECTO DEL ACEITE DE SEMILLA DE UVILLA  (***Pourouma cecropiifolia* **) EN LA SUSTITUCIÓN PARCIAL DE MANTECA DE CACAO, ESTABILIDAD OXIDATIVA Y CRISTALIZACIÓN DEL CHOCOLATE**

La manteca de cacao en la formulación de chocolates, es un componente importante que brinda el punto de fusión, estructura y cristalización, lo que permite que el chocolate se funda en la boca sin ser demasiado blando a temperatura ambiente.  El objetivo de este trabajo fue evaluar el efecto del aceite de semilla de uvilla en la sustitución parcial de manteca de cacao en la estabilidad oxidativa y cristalización del chocolate. Se obtuvo muestras de uvilla y cacao, se trasladó al Laboratorio de Ingeniería, se acondicionó y seco para obtener aceite de uvilla y nibs de cacao. Se realizó una caracterización física de las semillas de uvilla y se extrajo el aceite utilizando el método Soxhlet. El aceite se caracterizó mediante análisis de índice de acidez, índice de peróxidos, análisis reológico, espectroscopía Raman y calorimetría diferencial de barrido (DSC). Los resultados demostraron que el aceite de uvilla, está dentro de los estándares establecidos por el Codex Alimentarius, mayor viscosidad y punto de fusión más altos que la manteca de cacao, con una composición predominante de ácidos linoleico, bohémico y palmítico. En chocolates con sustituciones del 0 % al 20 % de aceite de uvilla no se observaron diferencias significativas (p > 0,05) en las propiedades térmicas, como los puntos de cristalización y fusión. Sin embargo, la estabilidad oxidativa mejoró significativamente (p < 0,05) con el aumento de aceite de uvilla, lo que sugiere que aporta mayor resistencia a la oxidación y una prolongación de vida útil del chocolate. Además, estos hallazgos sugieren que el aceite de uvilla es una alternativa viable para sustituir parcialmente la manteca de cacao en chocolates, mejorando su estabilidad oxidativa sin afectar las propiedades térmicas, lo que podría ser beneficioso para la industria chocolatera en la formulación de productos más duraderos.

**Palabras claves:** Aceite de uvilla (AU), manteca de cacao (CB), caracterización, propiedades térmicas, ácidos grasos, estabilidad oxidativa, chocolates.

I. **Introducción**                                                                                                                       

La demanda mundial de [manteca de cacao](https://www.sciencedirect.com/topics/agricultural-and-biological-sciences/cocoa-butter) _(CB), incrementa constantemente_, a diferencia de la producción, que no logra satisfacer esta demanda creciente, además la disponibilidad de este insumo es cada vez más limitada en los últimos años (Norazlina et al., 2021). Los principales factores causantes de esta oferta limitada y el elevado costo de los insumos para la producción de chocolates son las condiciones ambientales, edafológicas, además de las principales plagas y enfermedades que vienen atacando a las plantaciones de cacao en los últimos tiempos (Ghazani et al., 2018).

El chocolate es un alimento conocido y que tiene una alta demanda a nivel mundial, descrito como una mezcla que contiene dos fases principales: una fase continua, que contiene manteca de cacao, y otra fase dispersa compuesta por ingredientes como azúcar, cacao en polvo y leche en polvo. La fase predominante desempeña una función fundamental en la arquitectura del producto al crear una matriz cristalina que dispersa las partículas sólidas (Masuchi et al., 2014; Li & Liu, 2023). 

El chocolate tiene un contenido de polifenoles y grasas de alta calidad, por lo que se considera comercialmente como un super alimento (Glicerina et al., 2016; Medina-Mendoza et al., 2021). No obstante, las grasas presentes en el chocolate son propensas a [oxidarse](https://www.sciencedirect.com/topics/materials-science/oxidation-reaction) durante su procesamiento y almacenamiento (Dolatowska-Żebrowska et al., 2020). La prevención de su deterioro durante estos procesos podría determinar la calidad del producto.

II. Materiales y Métodos

Se utilizó éter de petróleo, solución de etanol, solución de fenolftaleína, hidróxido de potasio, cloroformo, ácido acético, KI, solución de almidón y etanol 96° adquiridos de Merck KGaA, Alemania.

Los frutos de cacao y uvilla fueron obtenidos de la Comunidad Nativa Bajo Naranjillo, distrito Awajun, provincia Rioja, departamento San Martín, Perú. Se recolectó 50 kg de frutos de uvilla en estado de madurez fisiológico, caracterizado por un color morado intenso. Los frutos fueron trasladados en bolsas de polipropileno de alta densidad con cierre tipo cremallera y trasladados al Laboratorio de Ingeniería (LABING) de la Universidad Nacional Toribio Rodríguez de Mendoza de Amazonas (UNTRM); donde fueron sometidas a un proceso de fermentación a temperatura ambiente durante 48 horas. Finalmente fueron seleccionadas y lavadas para extraerlas sus semillas para su posterior caracterización física y extracción de aceites.

Se recolectó 20 kg de cacao criollo *(Theobroma cacao)* de una finca localizada en el distrito de Awajún, luego trasladado al LABING de la UNTRM luego acondicionadas y secadas según Antunes et al. (2024). Además, se adquirieron otros ingredientes esenciales para el estudio, como la manteca de cacao y el azúcar, los cuales fueron proporcionados por la Cooperativa de Servicios Múltiples APROCAM, ubicada en la provincia de Bagua, departamento Amazonas, Perú.

## **2.1 Análisis de sus propiedades fisicoquímicas del aceite de semilla de uvilla**

## Se empleó el método AOAC 963.15 (AOAC, 2010) con algunas modificaciones. [[1]](https://www.zotero.org/google-docs/?OH3KY5) Inicialmente, se pesaron aproximadamente 5 g de muestra seca y triturada, la cual se envolvió en papel filtro para garantizar su retención durante el proceso. Posteriormente, la muestra se colocó en el equipo de extracción de grasa (Soxhlet).[Figure 1](?tab=t.0#bookmark=id.z3i7umfvk3no)A cada uno de los balones de extracción, previamente secados y pesados, se añadieron 150 ml de éter de petróleo [[2]](https://www.zotero.org/google-docs/?ReNEGf). Luego, se procedió a operar el equipo de acuerdo con las especificaciones del fabricante[[1]](https://www.zotero.org/google-docs/?l0bBXs).

Una vez concluida la extracción de grasa, se retiró la cápsula de extracción y el balón que contenía la grasa extraída se colocó en una estufa a 100 °C para eliminar los residuos del reactivo.[Table 1](?tab=t.0#bookmark=id.w18bu1lor8pl)






| **Ingredientes**       | **Niveles del factor** |                        |                        |                        |                         |
|------------------------|------------------------|------------------------|------------------------|------------------------|-------------------------|
|                        | *T~0~*                 | *T~1~*                 | *T~2~*                 | *T~3~*                 | *T~4~*                  |
| **CB (g)**             | 40                     | 38                     | 36                     | 34                     | 32                      |
| **AU (g)**             | 0                      | 2                      | 4                      | 6                      | 8                       |
| **Total (g)**          | 40                     | 40                     | 40                     | 40                     | 40                      |












: *Formulaciones de Chocolates con diferentes concentraciones de aceite de uvilla en tabletas de 40 g (g).* {#tbl:id.w18bu1lor8pl}






| **Ingredientes**       | **Niveles del factor** |                        |                        |                        |                         |
|------------------------|------------------------|------------------------|------------------------|------------------------|-------------------------|
|                        | *T~0~*                 | *T~1~*                 | *T~2~*                 | *T~3~*                 | *T~4~*                  |
| **Pasta de cacao (g)** | 70                     | 70                     | 70                     | 70                     | 70                      |
| **Azúcar (g)**         | 25                     | 25                     | 25                     | 25                     | 25                      |
| **CB (g)**             | 5                      | 4,75                   | 4,50                   | 3,5                    | 3                       |
| **AU**                 | 0                      | 0,25                   | 0,50                   | 0,75                   | 1                       |
| **Total**              | 100                    | 100                    | 100                    | 100                    | 100                     |




: *Ingredientes según niveles de formulación de los chocolates con sustitución parcial de aceite de uvilla (%).* {#tbl:id.utdb6pp32xq2}



![Semilla de lenteja](img_0.jpg){#fig:id.z3i7umfvk3no}





$$z=\frac{-b\pm\sqrt{b^2-4ac}}{2a}.\ z^{2g}$$



# II. Referencias

[1. 	Agrios, G.N. *Plant Pathology*; Elsevier, 2005; ISBN 978-0-08-047378-9.](https://www.zotero.org/google-docs/?60BaR9)

[2. 	Lopez-Nicora, H.; Soilán Duarte, L.C.; Caballero Mairesse, G.G.; Grabowski Ocampos, C.J.; Enciso Maldonado, G.A. *Manual de nematología agrícola, bases y procedimientos*; 1ra ed.; Universidad San Carlos, 2022; ISBN 978-99925-2-736-8.](https://www.zotero.org/google-docs/?60BaR9)